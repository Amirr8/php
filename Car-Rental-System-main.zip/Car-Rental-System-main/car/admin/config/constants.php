<?php
define('ROOT_URL', 'http://localhost/car/'); 
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'carrental');
