    <!--=======================FOOTER====================-->
    <footer>
      <div class="footer_socials">
        <a href="https://www.youtube.com/watch?v=a3Z7zEc7AXQ" target="blank"><i class="uil uil-youtube"></i></a>
        <a href="https://www.youtube.com/watch?v=a3Z7zEc7AXQ" target="blank"><i class="uil uil-facebook"></i></a>
        <a href="https://www.youtube.com/watch?v=a3Z7zEc7AXQ" target="blank"><i class="uil uil-instagram"></i></a>
      </div>
      <div class="container footer_container">
        <article>
          <h4>Categories</h4>
          <ul>
            <li><a href="">SUV</a></li>
            <li><a href="">COMPACT CARS</a></li>
            <li><a href="">ECONOMY CAR</a></li>
            <li><a href="">MINI VAN</a></li>
            <li><a href="">HYBRID CARS</a></li>
            <li><a href="">LUXURY CARS</a></li>
          </ul>
        </article>
        <article>
          <h4>Support</h4>
          <ul>
            <li><a href="">Online Support</a></li>
            <li><a href="">Call Numbers</a></li>
            <li><a href="">Emails</a></li>
            <li><a href="">Social Support</a></li>
            <li><a href="">Location</a></li>
            <li><a href="">Facebook</a></li>
          </ul>
        </article>
        <article>
          <h4>Permalink</h4>
          <ul>
            <li><a href="">Home</a></li>
            <li><a href="">About</a></li>
            <li><a href="">Services</a></li>
            <li><a href="">Contact</a></li>
          </ul>
        </article>
      </div>
      <div class="footer_copyright">
        <small>Copyright &copy; indians</small>
      </div>
    </footer>

<!--LINK TO JS-->
<script src="<?= ROOT_URL?>js/main.js"></script>
</body>
</html>